# 13 EJERCICIO PIPELINES - WEBHOOK - NGROK

Ejercicio 1 - OK
Ejercicio 2 con webhooks  - probando trigger
Ejercicio 3 - automatizado
Ejercicio 4 - ahora con slack notifications
